import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile-display',
  templateUrl: './profile-display.component.html',
  styleUrls: ['./profile-display.component.css']
})
export class ProfileDisplayComponent implements OnInit {

  profiles: any[] = [
    // Profile data...
  ];

  selectedProfile: any = null;

  constructor() { }

  ngOnInit(): void {
  }

  showSummary(profile: any): void {
    this.selectedProfile = profile;
  }
}
