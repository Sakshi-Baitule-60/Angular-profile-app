import { Component, Input, OnChanges, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-map',
  templateUrl: './map.component.html',
  styleUrls: ['./map.component.css']
})
export class MapComponent implements OnChanges {

  @Input() selectedProfile: any;
  
  constructor() { }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.selectedProfile) {
      this.loadMap();
    }
  }

  private loadMap(): void {
    // Load map related functionality here
  }
}
