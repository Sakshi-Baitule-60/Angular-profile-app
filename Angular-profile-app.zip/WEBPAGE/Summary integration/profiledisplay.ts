import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile-display',
  templateUrl: './profile-display.component.html',
  styleUrls: ['./profile-display.component.css']
})
export class ProfileDisplayComponent implements OnInit {

  profiles: any[] = [
    // Profile data...
  ];

  selectedProfile: any;

  constructor() { }

  ngOnInit(): void {
  }

  selectProfile(profile: any): void {
    this.selectedProfile = profile;
  }
}
