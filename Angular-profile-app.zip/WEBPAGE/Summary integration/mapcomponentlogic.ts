import { Component, Input, OnChanges, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-map',
  templateUrl: './map.component.html',
  styleUrls: ['./map.component.css']
})
export class MapComponent implements OnChanges {

  @Input() selectedProfile: any;

  private map: google.maps.Map;
  private marker: google.maps.Marker;

  constructor() { }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.selectedProfile && this.selectedProfile) {
      this.loadMap();
    }
  }

  private loadMap(): void {
    const mapOptions: google.maps.MapOptions = {
      center: { lat: this.selectedProfile.latitude, lng: this.selectedProfile.longitude },
      zoom: 15
    };
    this.map = new google.maps.Map(document.getElementById('map'), mapOptions);

    this.marker = new google.maps.Marker({
      position: { lat: this.selectedProfile.latitude, lng: this.selectedProfile.longitude },
      map: this.map,
      title: this.selectedProfile.name
    });
  }
}
