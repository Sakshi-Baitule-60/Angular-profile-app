import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AgmCoreModule } from '@agm/core';

import { AppComponent } from './app.component';
import { ProfileDisplayComponent } from './profile-display/profile-display.component';
import { MapComponent } from './map/map.component'; // Import the map component

@NgModule({
  declarations: [
    AppComponent,
    ProfileDisplayComponent,
    MapComponent // Include the map component
  ],
  imports: [
    BrowserModule,
    AgmCoreModule.forRoot({
      apiKey: 'YOUR_GOOGLE_MAPS_API_KEY' // Replace with your API key
    })
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
