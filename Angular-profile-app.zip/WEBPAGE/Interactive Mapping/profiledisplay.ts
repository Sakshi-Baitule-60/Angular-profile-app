
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile-display',
  templateUrl: './profile-display.component.html',
  styleUrls: ['./profile-display.component.css']
})
export class ProfileDisplayComponent implements OnInit {

  profiles: any[] = [
    {
      name: 'Alice Johnson',
      photo: 'profile1.jpg',
      description: 'Passionate coder and avid reader.',
      latitude: 37.7749,
      longitude: -122.4194 // Replace with actual coordinates
    },
    {
      name: 'Bob Smith',
      photo: 'profile2.jpg',
      description: 'Nature lover and travel enthusiast.',
      latitude: 34.0522,
      longitude: -118.2437 // Replace with actual coordinates
    },
    {
      name: 'Eve Williams',
      photo: 'profile3.jpg',
      description: 'Foodie and aspiring chef.',
      latitude: 40.7128,
      longitude: -74.0060 // Replace with actual coordinates
    }
  ];

  selectedProfile: any;

  constructor() { }

  ngOnInit(): void {
  }

  selectProfile(profile: any): void {
    this.selectedProfile = profile;
  }
}
