import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile-display',
  templateUrl: './profile-display.component.html',
  styleUrls: ['./profile-display.component.css']
})
export class ProfileDisplayComponent implements OnInit {

  profiles: any[] = [
    {
      name: 'Alice Johnson',
      photo: 'profile1.jpg',
      description: 'Passionate coder and avid reader.'
    },
    {
      name: 'Bob Smith',
      photo: 'profile2.jpg',
      description: 'Nature lover and travel enthusiast.'
    },
    {
      name: 'Eve Williams',
      photo: 'profile3.jpg',
      description: 'Foodie and aspiring chef.'
    }
  ];

  constructor() { }

  ngOnInit(): void {
  }

}
