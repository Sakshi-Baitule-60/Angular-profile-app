import { Component, Input, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-map',
  templateUrl: './map.component.html',
  styleUrls: ['./map.component.css']
})
export class MapComponent {

  @Input() selectedProfile: any;
  @Output() closeMap = new EventEmitter<void>();
  
  constructor() { }

}
